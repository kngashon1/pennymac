import boto3
import logging
from datetime import datetime, timedelta

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize EC2 client
ec2 = boto3.client('ec2')

def lambda_handler(event, context):
    try:
        # Get all snapshots owned by this account
        snapshots = ec2.describe_snapshots(OwnerIds=['self'])['Snapshots']
        cutoff_date = datetime.utcnow() - timedelta(days=365)

        for snapshot in snapshots:
            start_time = snapshot['StartTime'].replace(tzinfo=None)
            if start_time < cutoff_date:
                snapshot_id = snapshot['SnapshotId']
                try:
                    ec2.delete_snapshot(SnapshotId=snapshot_id)
                    logger.info(f"Deleting snapshot: {snapshot_id}")
                except Exception as e:
                    logger.error(f"Error deleting snapshot {snapshot_id}: {str(e)}")
    except Exception as e:
        logger.error(f"Error retrieving snapshots: {str(e)}")